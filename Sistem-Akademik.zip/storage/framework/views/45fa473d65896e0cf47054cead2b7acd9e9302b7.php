 <!-- Menyertakan layout orang tua -->

<?php $__env->startSection('content'); ?> <!-- Memulai section untuk konten -->
<div class="max-w-3xl mx-auto mt-10 bg-white p-6 rounded-lg shadow-md">
    <h1 class="text-2xl font-bold text-center">KHS Mahasiswa</h1>
    <p class="mt-4 text-center">Berikut adalah KHS yang berhasil diambil oleh mahasiswa.</p>

    <!-- Tabel KHS -->
    <div class="mt-6 overflow-x-auto">
        <table class="min-w-full bg-white">
            <thead>
                <tr>
                    <th class="py-2 px-4 border-b">Mata Kuliah</th>
                    <th class="py-2 px-4 border-b">Semester</th>
                    <th class="py-2 px-4 border-b">Tahun Akademik</th>
                    <th class="py-2 px-4 border-b">Nilai Angka</th>
                    <th class="py-2 px-4 border-b">Nilai Huruf</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $khsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="py-2 px-4 border-b"><?php echo e($khs->matkul->name); ?></td> <!-- Asumsikan Anda memiliki relasi 'matkul' -->
                    <td class="py-2 px-4 border-b"><?php echo e($khs->semester); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($khs->tahun_akademik); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($khs->nilai_angka); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($khs->nilai_huruf); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?> <!-- Menutup section untuk konten -->

<?php echo $__env->make('layouts.orangtua', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/orangtua/app/khs.blade.php ENDPATH**/ ?>