<!-- resources/views/orangtua/login.blade.php -->
  <!-- Ganti dengan layout yang sesuai jika perlu -->

<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto mt-20 bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-2xl font-bold text-center">Login Orang Tua</h2>

        <?php if(session('error')): ?>
            <div class="text-red-500 text-sm mt-2"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(url('/orangtua/login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mt-4">
                <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                <input type="text" name="username" id="username" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-200" required>
            </div>
            <div class="mt-4">
                <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                <input type="password" name="password" id="password" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-200" required>
            </div>
            <button type="submit" class="mt-6 w-full bg-blue-600 text-white py-2 rounded-lg">Login</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/orangtua/login.blade.php ENDPATH**/ ?>