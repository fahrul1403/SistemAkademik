

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-4">Edit Mata Kuliah</h1>

<form action="<?php echo e(route('admin.matkul.update', $matkul->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-4">
        <label for="kode" class="block text-sm font-medium text-gray-700">Kode</label>
        <input type="text" name="kode" id="kode" value="<?php echo e($matkul->kode); ?>" class="mt-1 block w-full border-gray-300 rounded-md" required>
    </div>
    <div class="mb-4">
        <label for="matkul" class="block text-sm font-medium text-gray-700">Mata Kuliah</label>
        <input type="text" name="matkul" id="matkul" value="<?php echo e($matkul->matkul); ?>" class="mt-1 block w-full border-gray-300 rounded-md" required>
    </div>
    <div class="mb-4">
        <label for="sks" class="block text-sm font-medium text-gray-700">SKS</label>
        <input type="number" name="sks" id="sks" value="<?php echo e($matkul->sks); ?>" class="mt-1 block w-full border-gray-300 rounded-md" required>
    </div>
    <div class="mb-4">
        <label for="kategori" class="block text-sm font-medium text-gray-700">Kategori</label>
        <input type="text" name="kategori" id="kategori" value="<?php echo e($matkul->kategori); ?>" class="mt-1 block w-full border-gray-300 rounded-md" required>
    </div>
    <div class="mb-4">
        <label for="smt" class="block text-sm font-medium text-gray-700">Semester</label>
        <input type="number" name="smt" id="smt" value="<?php echo e($matkul->smt); ?>" class="mt-1 block w-full border-gray-300 rounded-md" required>
    </div>
    <div class="mb-4">
        <label for="semester" class="block text-sm font-medium text-gray-700">Semester (Ganjil/Genap)</label>
        <input type="text" name="semester" id="semester" value="<?php echo e($matkul->semester); ?>" class="mt-1 block w-full border-gray-300 rounded-md" required>
    </div>
    <div class="mb-4">
        <label for="id_prodi" class="block text-sm font-medium text-gray-700">ID Program Studi</label>
        <input type="number" name="id_prodi" id="id_prodi" value="<?php echo e($matkul->id_prodi); ?>" class="mt-1 block w-full border-gray-300 rounded-md" required>
    </div>
    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/admin/matkul/edit.blade.php ENDPATH**/ ?>