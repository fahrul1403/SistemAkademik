

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-4">Detail Pembayaran</h1>

<div class="mb-4">
    <strong>ID Pembayaran:</strong> <?php echo e($pembayaran->id); ?>

</div>
<div class="mb-4">
    <strong>User ID:</strong> <?php echo e($pembayaran->user_id); ?>

</div>
<div class="mb-4">
    <strong>Jumlah:</strong> Rp. <?php echo e(number_format($pembayaran->jumlah, 2)); ?>

</div>
<div class="mb-4">
    <strong>Status:</strong> <?php echo e($pembayaran->status); ?>

</div>
<div class="mb-4">
    <strong>Bukti Pembayaran:</strong>
    <?php if($pembayaran->bukti_pembayaran): ?>
        <div class="mt-2">
            <a href="<?php echo e(asset('storage/' . $pembayaran->bukti_pembayaran)); ?>" target="_blank">
                <img src="<?php echo e(asset('storage/' . $pembayaran->bukti_pembayaran)); ?>" alt="Bukti Pembayaran" class="w-64 h-auto">
            </a>
        </div>
    <?php else: ?>
        <span class="text-gray-500">Belum ada bukti pembayaran</span>
    <?php endif; ?>
</div>

<a href="<?php echo e(route('admin.pembayaran.index')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded">Kembali</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/admin/pembayaran/show.blade.php ENDPATH**/ ?>