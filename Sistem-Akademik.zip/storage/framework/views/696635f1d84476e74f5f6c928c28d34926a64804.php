 <!-- Menyertakan layout orang tua -->

<?php $__env->startSection('content'); ?> <!-- Memulai section untuk konten -->
<div class="max-w-3xl mx-auto mt-10 bg-white p-6 rounded-lg shadow-md">
    <h1 class="text-2xl font-bold text-center">Profil Mahasiswa</h1>
    <p class="mt-4 text-center">Berikut adalah informasi profil mahasiswa Anda.</p>

    <div class="mt-6">
        <div class="bg-gray-100 p-4 rounded-lg shadow-md">
            <h2 class="font-bold text-lg">Informasi Pribadi</h2>
            <p class="mt-2"><strong>Nama:</strong> <?php echo e($mahasiswa->nama); ?></p>
            <p class="mt-2"><strong>Email:</strong> <?php echo e($mahasiswa->email); ?></p>
            <p class="mt-2"><strong>Jurusan:</strong> <?php echo e($mahasiswa->jurusan); ?></p>
            <p class="mt-2"><strong>Nomor Induk Mahasiswa:</strong> <?php echo e($mahasiswa->nim); ?></p>
            <p class="mt-2"><strong>Telepon:</strong> <?php echo e($mahasiswa->telepon); ?></p>
        </div>
    </div>

    <div class="mt-6 text-center">
        <a href="<?php echo e(route('orangtua.app.dashboard')); ?>" class="bg-blue-600 text-white py-2 px-4 rounded-lg shadow-md hover:bg-blue-500 transition">Kembali ke Dashboard</a>
    </div>
</div>
<?php $__env->stopSection(); ?> <!-- Menutup section untuk konten -->

<?php echo $__env->make('layouts.orangtua', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/orangtua/app/profile.blade.php ENDPATH**/ ?>