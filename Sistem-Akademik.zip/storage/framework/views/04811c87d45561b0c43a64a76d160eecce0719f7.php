

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-4xl font-bold text-blue-600 mb-6">Data KHS Anda <i class="fas fa-book-open"></i></h1>

    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-4 rounded-lg shadow-md mb-4">
            <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($khsData->isEmpty()): ?>
        <p class="text-gray-500">Tidak ada data KHS yang tersedia. <i class="fas fa-exclamation-circle"></i></p>
    <?php else: ?>
        <table class="min-w-full bg-white border border-gray-300 shadow-md rounded-lg overflow-hidden">
            <thead class="bg-blue-100">
                <tr>
                    <th class="py-3 px-4 border-b text-left text-blue-700">Semester</th>
                    <th class="py-3 px-4 border-b text-left text-blue-700">Mata Kuliah</th>
                    <th class="py-3 px-4 border-b text-left text-blue-700">Nilai</th>
                    <th class="py-3 px-4 border-b text-left text-blue-700">Tahun Akademik</th>
                    <th class="py-3 px-4 border-b text-left text-blue-700">Tanggal</th>
                    <th class="py-3 px-4 border-b text-left text-blue-700">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $khsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-blue-50 transition duration-200">
                        <td class="py-2 px-4 border-b"><?php echo e($khs->semester); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($khs->matkul->matkul); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($khs->nilai_angka); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($khs->tahun_akademik); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($khs->created_at->format('d-m-Y')); ?></td>
                        <td class="py-2 px-4 border-b">
                            <form action="<?php echo e(route('admin.khs.destroy', $khs->id)); ?>" method="POST" class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded-lg" onclick="return confirm('Yakin ingin menghapus?')">
                                    <i class="fas fa-trash-alt"></i> Hapus
                                </button>
                            </form>
                            <button type="button" class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-3 rounded-lg" onclick="editKHS(<?php echo e($khs->id); ?>, '<?php echo e($khs->semester); ?>', '<?php echo e($khs->nilai_angka); ?>', '<?php echo e($khs->id_matkul); ?>', '<?php echo e($khs->tahun_akademik); ?>')">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <h2 class="text-3xl font-bold mt-8 mb-4 text-blue-600">Tambah / Edit KHS <i class="fas fa-plus-circle"></i></h2>
    <form action="<?php echo e(route('khs.submit')); ?>" method="POST" class="mt-4 bg-white shadow-md rounded-lg p-6" id="khsForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="khs_id" name="khs_id" value="">
        
        <div class="mb-4">
            <label for="semester" class="block text-sm font-medium text-gray-700">Semester</label>
            <input type="text" id="semester" name="semester" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
        </div>

        <div class="mb-4">
            <label for="id_matkul" class="block text-sm font-medium text-gray-700">Mata Kuliah</label>
            <select id="id_matkul" name="id_matkul" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                <option value="">Pilih Mata Kuliah</option>
                <?php $__currentLoopData = $matkuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matkul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($matkul->id); ?>"><?php echo e($matkul->matkul); ?></option> <!-- Pastikan 'nama' adalah kolom yang ada di tabel mata kuliah -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-4">
            <label for="nilai_angka" class="block text-sm font-medium text-gray-700">Nilai</label>
            <input type="text" id="nilai_angka" name="nilai_angka" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
        </div>

        <div class="mb-4">
            <label for="tahun_akademik" class="block text-sm font-medium text-gray-700">Tahun Akademik</label>
            <input type="text" id="tahun_akademik" name="tahun_akademik" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
        </div>

        <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg">
            <i class="fas fa-save"></i> Simpan KHS
        </button>
    </form>

    <div class="mt-6">
        <a href="<?php echo e(route('app.index')); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg">
            <i class="fas fa-arrow-left"></i> Kembali ke Halaman Utama
        </a>
    </div>
</div>

<script>
    function editKHS(id, semester, nilai_angka, id_matkul, tahun_akademik) {
        document.getElementById('khs_id').value = id;
        document.getElementById('semester').value = semester;
        document.getElementById('nilai_angka').value = nilai_angka;
        document.getElementById('id_matkul').value = id_matkul; // Set id_matkul
        document.getElementById('tahun_akademik').value = tahun_akademik; // Set tahun_akademik
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/app/khs.blade.php ENDPATH**/ ?>