

<?php $__env->startSection('content'); ?>
    <h2 class="text-2xl font-semibold mb-6">Kelola KHS</h2>
    
    <div class="mb-4">
        <a href="<?php echo e(route('admin.khs.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded">
            Tambah KHS
        </a>
    </div>
    
    <table class="min-w-full bg-white border border-gray-300">
        <thead>
            <tr>
                <th class="py-2 px-4 border-b">No</th>
                <th class="py-2 px-4 border-b">Nama Mahasiswa</th>
                <th class="py-2 px-4 border-b">Mata Kuliah</th>
                <th class="py-2 px-4 border-b">Nilai</th>
                <th class="py-2 px-4 border-b">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $khslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $khs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="py-2 px-4 border-b"><?php echo e($index + 1); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($khs->users->nama); ?></td> <!-- Pastikan ada field nama di model User -->
                    <td class="py-2 px-4 border-b"><?php echo e($khs->mata_kuliah); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($khs->nilai); ?></td>
                    <td class="py-2 px-4 border-b">
                        <a href="<?php echo e(route('admin.khs.edit', $khs->id)); ?>" class="text-blue-500">Edit</a>
                        <form action="<?php echo e(route('admin.khs.destroy', $khs->id)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/admin/kelolaKHS.blade.php ENDPATH**/ ?>