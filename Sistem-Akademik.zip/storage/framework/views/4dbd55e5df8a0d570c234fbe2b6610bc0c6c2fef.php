

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-6">Dashboard Admin</h1>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-lg font-semibold">Jumlah Mahasiswa</h2>
            <p class="text-2xl font-bold mt-2"><?php echo e($jumlahMahasiswa); ?></p>
        </div>
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-lg font-semibold">Jumlah Orang Tua</h2>
            <p class="text-2xl font-bold mt-2"><?php echo e($jumlahOrangTua); ?></p>
        </div>
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-lg font-semibold">Jumlah KRS Terkonfirmasi</h2>
            <p class="text-2xl font-bold mt-2"><?php echo e($jumlahKRS); ?></p>
        </div>
    </div>

    <div class="mt-6">
        <a href="<?php echo e(route('admin.kelola')); ?>" class="inline-block px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
            Kelola Data
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>