

<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl font-bold mb-6">Kelola Data Mahasiswa</h1>

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white rounded-lg shadow-md">
            <thead>
                <tr class="bg-gray-800 text-white">
                    <th class="py-3 px-4">Nama</th>
                    <th class="py-3 px-4">NIM</th>
                    <th class="py-3 px-4">Email</th>
                    <th class="py-3 px-4 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-gray-100 transition duration-200">
                        <td class="py-2 px-4"><?php echo e($mhs->username); ?></td>
                        <td class="py-2 px-4"><?php echo e($mhs->id); ?></td>
                        <td class="py-2 px-4"><?php echo e($mhs->email); ?></td>
                        <td class="py-2 px-4 text-center">
                            <a href="<?php echo e(route('admin.edit', $mhs->id)); ?>" class="text-blue-500 hover:underline transition duration-150">Edit</a> |
                            <form action="<?php echo e(route('admin.destroy', $mhs->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-500 hover:underline transition duration-150">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <?php if(session('success')): ?>
        <div class="mt-4 text-green-500">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/admin/kelola.blade.php ENDPATH**/ ?>