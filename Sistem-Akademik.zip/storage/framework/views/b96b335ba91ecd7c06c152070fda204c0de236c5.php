

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Edit KHS</h1>

    <form action="<?php echo e(route('admin.khs.update', $kh->id)); ?>" method="POST" class="bg-white shadow-md rounded-lg p-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700">Mahasiswa</label>
            <select name="id_user" class="w-full px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300">
                <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($mahasiswa->id); ?>" <?php echo e($mahasiswa->id == $kh->id_user ? 'selected' : ''); ?>>
                        <?php echo e($mahasiswa->username); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700">Mata Kuliah</label>
            <select name="id_matkul" class="w-full px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300">
                <?php $__currentLoopData = $matkuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matkul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($matkul->id); ?>" <?php echo e($matkul->id == $kh->id_matkul ? 'selected' : ''); ?>>
                        <?php echo e($matkul->matkul); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700">Semester</label>
            <input type="text" name="semester" value="<?php echo e($kh->semester); ?>" class="w-full px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300" required>
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700">Tahun Akademik</label>
            <input type="text" name="tahun_akademik" value="<?php echo e($kh->tahun_akademik); ?>" class="w-full px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300" required>
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700">Nilai Angka</label>
            <input type="number" name="nilai_angka" value="<?php echo e($kh->nilai_angka); ?>" class="w-full px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300" required>
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700">Nilai Huruf</label>
            <select name="nilai_huruf" class="w-full px-4 py-2 border rounded-lg focus:ring focus:ring-blue-300" required>
                <option value="A" <?php echo e($kh->nilai_huruf == 'A' ? 'selected' : ''); ?>>A</option>
                <option value="B" <?php echo e($kh->nilai_huruf == 'B' ? 'selected' : ''); ?>>B</option>
                <option value="C" <?php echo e($kh->nilai_huruf == 'C' ? 'selected' : ''); ?>>C</option>
                <option value="D" <?php echo e($kh->nilai_huruf == 'D' ? 'selected' : ''); ?>>D</option>
                <option value="E" <?php echo e($kh->nilai_huruf == 'E' ? 'selected' : ''); ?>>E</option>
                <option value="F" <?php echo e($kh->nilai_huruf == 'F' ? 'selected' : ''); ?>>F</option>
            </select>
        </div>

        <button type="submit" class="bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-700 hover:to-blue-900 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300 flex items-center">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"></path>
            </svg>
            Update
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/admin/khs/edit.blade.php ENDPATH**/ ?>