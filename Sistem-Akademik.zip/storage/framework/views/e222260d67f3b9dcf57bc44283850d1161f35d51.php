

<?php $__env->startSection('content'); ?>

<div class="container mx-auto px-4 py-6">
    <h1 class="text-3xl font-bold mb-6 text-blue-600">Daftar KRS</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-4 mb-4 rounded shadow">
            <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.krs.create')); ?>" class="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300 flex items-center">
        <i class="fas fa-plus mr-2"></i> Tambah KRS
    </a>

    <table class="min-w-full mt-4 bg-white shadow-md rounded-lg overflow-hidden">
        <thead class="bg-blue-500 text-white">
            <tr>
                <th class="border px-4 py-2">ID</th>
                <th class="border px-4 py-2">Mahasiswa</th>
                <th class="border px-4 py-2">Mata Kuliah</th>
                <th class="border px-4 py-2">Semester</th>
                <th class="border px-4 py-2">Tahun Akademik</th>
                <th class="border px-4 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $krs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover:bg-gray-100 transition duration-300">
                <td class="border px-4 py-2"><?php echo e($item->id); ?></td>
                <td class="border px-4 py-2"><?php echo e($item->user->username); ?></td>
                <td class="border px-4 py-2"><?php echo e($item->matkul->matkul); ?></td>
                <td class="border px-4 py-2"><?php echo e($item->semester); ?></td>
                <td class="border px-4 py-2"><?php echo e($item->tahun_akademik); ?></td>
                <td class="border px-4 py-2 flex space-x-2">
                    <a href="<?php echo e(route('admin.krs.edit', $item->id)); ?>" class="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600 transition duration-300 flex items-center">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <form action="<?php echo e(route('admin.krs.destroy', $item->id)); ?>" method="POST" class="inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 transition duration-300 flex items-center" onclick="return confirm('Yakin ingin menghapus?')">
                            <i class="fas fa-trash"></i> Hapus
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Akademik\resources\views/admin/krs/index.blade.php ENDPATH**/ ?>