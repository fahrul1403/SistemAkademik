<!-- resources/views/admin/orangtua/create.blade.php -->


<?php $__env->startSection('title', 'Tambah Orang Tua Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Tambah Orang Tua Mahasiswa</h1>
    
    <!-- resources/views/admin/orangtua/create.blade.php -->
<form action="<?php echo e(route('admin.orangtua.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-4">
        <label for="username" class="block text-gray-700">Username</label>
        <input type="text" name="username" id="username" required class="border rounded p-2 w-full">
    </div>
    <div class="mb-4">
        <label for="email" class="block text-gray-700">Email</label>
        <input type="email" name="email" id="email" required class="border rounded p-2 w-full">
    </div>
    <div class="mb-4">
        <label for="password" class="block text-gray-700">Password</label>
        <input type="password" name="password" id="password" required class="border rounded p-2 w-full">
    </div>
    <div class="mb-4">
        <label for="mahasiswa_id" class="block text-gray-700">Mahasiswa</label>
        <select name="mahasiswa_id" id="mahasiswa_id" required class="border rounded p-2 w-full">
            <option value="">Pilih Mahasiswa</option>
            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($mhs->id); ?>"><?php echo e($mhs->username); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Simpan</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/admin/orangtua/create.blade.php ENDPATH**/ ?>