

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto mt-8 p-6 bg-white rounded-lg shadow-lg">
    <h1 class="text-3xl font-semibold text-center text-blue-600 mb-6">Profil Anda</h1>

    
    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-3 rounded-lg mb-6 text-center">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="text-center mb-8">
        <h2 class="text-xl font-bold text-gray-800"><?php echo e($user->username); ?></h2>
        <p class="text-gray-600"><?php echo e($user->email); ?></p>
       
    </div>

    
    <form action="<?php echo e(url('profile')); ?>" method="POST" class="bg-gray-50 p-6 rounded-lg shadow-md">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label for="name" class="block text-gray-700 font-semibold">Nama Lengkap</label>
            <input type="text" id="name" name="name" value="<?php echo e($user->username); ?>" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring-2 focus:ring-blue-500" required>
        </div>
        <div class="mb-4">
            <label for="role" class="block text-gray-700 font-semibold">Role</label>
            <input type="text" id="role" name="role" value="<?php echo e($user->role); ?>" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring-2 focus:ring-blue-500" required>
        </div>
        <div class="mb-4">
            <label for="email" class="block text-gray-700 font-semibold">Email</label>
            <input type="text" id="email" name="email" value="<?php echo e($user->email); ?>" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring-2 focus:ring-blue-500" required>
        </div>
        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300 ease-in-out">Perbarui Profil</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/app/profile.blade.php ENDPATH**/ ?>