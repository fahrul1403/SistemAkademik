 

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl font-bold mb-4">Daftar Mahasiswa</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-200 text-green-800 p-4 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.mahasiswa.create')); ?>" class="inline-block mb-4 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-500 transition duration-150">Tambah Mahasiswa</a>

    <table class="min-w-full bg-white border border-gray-200">
        <thead class="bg-gray-100">
            <tr>
                <th class="py-2 px-4 text-left text-sm font-medium text-gray-600">Username</th>
                <th class="py-2 px-4 text-left text-sm font-medium text-gray-600">Email</th>
                <th class="py-2 px-4 text-left text-sm font-medium text-gray-600">Role</th>
                <th class="py-2 px-4 text-left text-sm font-medium text-gray-600">Aksi</th>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
            <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="py-2 px-4"><?php echo e($mahasiswa->username); ?></td>
                    <td class="py-2 px-4"><?php echo e($mahasiswa->email); ?></td>
                    <td class="py-2 px-4"><?php echo e(ucfirst($mahasiswa->role)); ?></td>
                    <td class="py-2 px-4 flex space-x-2">
                        <a href="<?php echo e(route('admin.mahasiswa.edit', $mahasiswa->id)); ?>" class="text-yellow-500 hover:underline"><i class="fas fa-edit"></i> Edit</a>
                        <form action="<?php echo e(route('admin.mahasiswa.destroy', $mahasiswa->id)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500 hover:underline ml-4"><i class="fas fa-trash-alt"></i> Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Akademik\resources\views/admin/mahasiswa/index.blade.php ENDPATH**/ ?>