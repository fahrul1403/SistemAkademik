<!-- resources/views/admin/orangtua/index.blade.php -->


<?php $__env->startSection('title', 'Daftar Orang Tua Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Daftar Orang Tua Mahasiswa</h1>
    <a href="<?php echo e(route('admin.orangtua.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded">Tambah Orang Tua</a>
    
    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-2 mt-2 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <table class="min-w-full mt-4 bg-white border rounded">
        <thead>
            <tr>
                <th class="border px-4 py-2">ID</th>
                <th class="border px-4 py-2">Username</th>
                <th class="border px-4 py-2">Email</th>
                <th class="border px-4 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orangTuaMahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orangTua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border px-4 py-2"><?php echo e($orangTua->id); ?></td>
                    <td class="border px-4 py-2"><?php echo e($orangTua->username); ?></td>
                    <td class="border px-4 py-2"><?php echo e($orangTua->email); ?></td>
                    <td class="border px-4 py-2">
                        <a href="<?php echo e(route('admin.orangtua.edit', $orangTua->id)); ?>" class="text-yellow-500">Edit</a>
                        <form action="<?php echo e(route('admin.orangtua.destroy', $orangTua->id)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/admin/orangtua/index.blade.php ENDPATH**/ ?>