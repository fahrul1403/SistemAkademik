

<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl font-bold mb-6">Edit Data Mahasiswa</h1>

    <form action="<?php echo e(route('admin.update', $mahasiswa->id)); ?>" method="POST" class="bg-white shadow-md rounded-lg p-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label for="username" class="block text-gray-700 font-semibold">Nama:</label>
            <input type="text" id="username" name="username" value="<?php echo e(old('username', $mahasiswa->username)); ?>" 
                   class="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:ring focus:ring-blue-300 focus:outline-none transition duration-150" required>
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label for="email" class="block text-gray-700 font-semibold">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo e(old('email', $mahasiswa->email)); ?>" 
                   class="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:ring focus:ring-blue-300 focus:outline-none transition duration-150" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="w-full bg-blue-600 text-white rounded-lg px-4 py-2 hover:bg-blue-700 transition duration-200">Update</button>
        <a href="<?php echo e(route('admin.kelola')); ?>" class="block mt-4 text-center text-gray-500 hover:underline">Kembali</a>
    </form>

    <?php if(session('success')): ?>
        <div class="mt-4 text-green-500">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistem-Akademik\resources\views/admin/editmahasiswa.blade.php ENDPATH**/ ?>