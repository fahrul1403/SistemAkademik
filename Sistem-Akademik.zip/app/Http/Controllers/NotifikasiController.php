<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Notifikasi; // Pastikan model Notifikasi sudah ada

class NotifikasiController extends Controller
{
    /**
     * Menampilkan daftar notifikasi untuk pengguna.
     *
     * @return \Illuminate\View\View
     */

}